clear all
close all

h_atm=fspecial('gaussian', 5, 1);   % atmosfersko zamucenje
h_hp=immaskhp(5);   % horizontalni pomak
h_vp=immaskvp(5);   % vertikalni pomak

imft3d(h_atm);  % OTF za atmosfersko zamucenje
imft3d([zeros(2, 5); h_hp; zeros(2, 5)]);   % OTF za horizontalni pomak
imft3d([zeros(5, 2) h_vp zeros(5, 2)]);   % OTF za vertikalni pomak

