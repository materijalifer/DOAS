clear all
close all

s=rgb2gray(imread('2.2.01.tiff'));  % slika
s=imresize(s, .5);      % predugo traje sa pravom velicinom
psf=get_psf();  % psf
s_d=conv2(double(s), psf, 'same');  % degradirana slika

% skaliramo vrijednosti slika na raspon [0, 1]
s01=imscale(s);
s_d01=imscale(s_d);
sn_d01=imnoise(s_d01, 'gaussian', 0, 0.001);

[psf_h, psf_w] = size(psf);
[s_h, s_w] = size(s_d);
th=psf_h+s_h-1;
tw=psf_w+s_w-1;
th=2^(fix(log2(th))+1);
tw=2^(fix(log2(tw))+1);

hx = fix(th/2) - fix(psf_h/2);
hy = fix(tw/2) - fix(psf_w/2);
H = zeros(th,tw);
H(hx:hx+psf_h-1, hy:hy+psf_w-1) = psf;
H = fft2(fliplr(flipud(fftshift(H))), th, tw);

H_inv=1./H;

S = fft2(s_d01, th, tw);
Sn = fft2(sn_d01, th, tw);


s_rest=ifft2(S.*H_inv);
sn_rest=ifft2(Sn.*H_inv);

