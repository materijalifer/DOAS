function slikaw = iminverzni(slika, h)


% za pravi inverzni: p = -1
% p = 0.0001;

% za pseudoinverzni: p = neki mali mali broj
% p = 0.01;

%p = 0.00001;
p=-1;


% Skaliraj ulaznu sliku i normiraj impulsni odziv.
slika = imscale(slika);
h = double(h);
h = h ./ sum2(h);

% Ukloni srednju vrijednost.
sr = mean2(slika);

[hn, hm] = size(h);
[sn, sm] = size(slika);
n = hn + sn - 1;
m = hm + sm - 1;
n = 2^( fix(log2(n)) + 1);
m = 2^( fix(log2(m)) + 1);

hx = fix(n/2) - fix(hn/2);
hy = fix(m/2) - fix(hm/2);
hDFT = zeros(n,m);
hDFT(hx:hx+hn-1, hy:hy+hm-1) = h;
hDFT = fftshift(hDFT);
hDFT = flipud(hDFT);
hDFT = fliplr(hDFT);
hDFT = fft2(hDFT, n, m);
slikaDFT = fft2(slika, n, m);

[s1, s2] = size(hDFT);

H = ones([s1,s2]);
i = find(abs(hDFT)<=p);

hDFT(i)=p;
H=H./hDFT;
H(i)=0;

slikawDFT = slikaDFT .* H;

slikaw = ifft2(slikawDFT);
slikaw = real(slikaw(1:sn, 1:sm)); 
