function y=get_psf()

h_atm=fspecial('gaussian', 5, 1);   % atmosfersko zamucenje
h_hp=immaskhp(14);   % horizontalni pomak
h_vp=immaskvp(10);   % vertikalni pomak

y=conv2(conv2(h_atm, h_hp), h_vp);  % ukupni psf
