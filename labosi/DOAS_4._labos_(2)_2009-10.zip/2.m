clear all
close all

s=rgb2gray(imread('2.2.01.tiff'));

psf=get_psf();

mesh(psf)
title('prikaz impulsnog odziva degradacije');

imft3d(psf) % OTF

s_d=conv2(double(s), psf);

figure, imagesc(s), colormap(gray);
title('originalna slika')

figure, imagesc(s_d), colormap(gray);
title('filtrirana slika');
